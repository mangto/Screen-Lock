from pygame import Rect, Surface, SRCALPHA
from data.scripts.draw import *
from data.scripts.fonts import *
from data.scripts.colors import *
from data.scripts.icon import *

class UI:

    objects = []

    class TextInput:
        def __init__(self, surface:Surface, rect:Rect,
                     color:tuple[int, int, int],
                     border:tuple[int, int, int], width:int=1, radius:float=0.98,
                     ActiveColor:tuple[int, int, int] = Colors.Real.Red,
                     text:str="", TextColor:tuple[int, int, int]=Colors.Real.Black,
                     hint:str="", font:Font=None, HintColor:tuple[int, int, int]=Colors.Real.Black,
                     password:bool=False,
                     ) -> None:
            UI.objects.append(self)

            self.surface = surface
            self.rect = rect
            self.color = color
            self.border = border
            self.width = width
            self.radius = radius
            self.hint = hint
            self.font = font
            self.HintColor = HintColor
            self.text = text
            self.TextColor = TextColor
            self.ActiveColor = ActiveColor
            self.password = password


            self.activated = False
            self.hovering = False
            self.lasthovering = False
            self.hitbox = pygame.Surface((self.rect[2], self.rect[3]))
            draw.rrect(self.hitbox, [0, 0, self.rect[2], self.rect[3]], Colors.Real.White, self.radius)

            self.plate = Surface((rect[2], rect[3]), SRCALPHA)
            draw.rrect(self.plate, [0, 0, self.rect[2], self.rect[3]], self.border, self.radius) # border
            draw.rrect(self.plate, 
                    [self.width, self.width, self.rect[2]-self.width*2, self.rect[3]-self.width*2],
                    self.color, self.radius)
            
            self.activeplate = Surface((rect[2], rect[3]), SRCALPHA)
            draw.rrect(self.activeplate, [0, 0, self.rect[2], self.rect[3]], self.ActiveColor, self.radius) # border
            draw.rrect(self.activeplate, 
                    [self.width, self.width, self.rect[2]-self.width*2, self.rect[3]-self.width*2],
                    self.color, self.radius)
            pass

        def draw(self, **settings) -> None:

            plate = self.plate
            if (self.activated): plate = self.activeplate

            self.surface.blit(plate, (self.rect[0], self.rect[1]))
            mouse = settings.get("mouse", (0, 0))
            KeyPressed = settings.get("KeyPressed", [])
            MouseState = settings.get("MouseState", [0]*6)

            # hit
            pos = mouse[0] - self.rect[0], mouse[1] - self.rect[1]
            if (pos[0]>=0 and pos[1]>=0 and pos[0]<self.rect[2] and pos[1]<self.rect[3]):
                color = self.hitbox.get_at(pos)
                if (color != Colors.Real.Black):
                    self.hovering = True
                    pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_IBEAM)

                    if (MouseState[1]):
                        self.activated = True

                else:
                    self.hovering = False
            else:
                self.hovering = False

            if (not self.hovering and MouseState[1]):
                self.activated = False

            if (not self.hovering and self.lasthovering): pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_ARROW)
            self.lasthovering = self.hovering

                
            # write
            if (self.activated):
                for c in KeyPressed:
                    if (len(c) == 1): self.text += c
                    elif (c == "backspace"): self.text = self.text[:-1]
                    elif (c == "spacebar"): self.text += " "

            # hint
            if (self.hint and self.font and not self.activated and not self.activated and not self.text):
                draw.text(self.hint, self.font, self.surface,
                            self.rect[0]+self.rect[3]//2, self.rect[1]+self.rect[3]//2,
                            "cenleft", self.HintColor
                        )
            if (self.text):
                text = self.text
                if (self.password): text = "*"*(len(self.text)-1)+self.text[-1]
                draw.text(text, self.font, self.surface,
                          self.rect[0]+self.rect[3]//2, self.rect[1]+self.rect[3]//2,
                            "cenleft", self.TextColor
                        )


            return
        

    class Button:
        def __init__(self, surface:Surface, rect:Rect,
                     color:tuple[int, int, int] = Colors.Real.White,
                     ActiveColor:tuple[int, int, int] = Colors.Real.Gray,
                     border:tuple[int, int, int] = Colors.Real.Black, width:int=1, radius:float=0.98,
                     icon:str="", IconColor:tuple[int, int, int]=Colors.Real.Black, IconThickness:str="r",
                     function="", ) -> None:
            UI.objects.append(self)

            self.surface = surface
            self.rect = rect
            self.color = color
            self.border = border
            self.width = width
            self.radius = radius
            self.function = function
            self.ActiveColor = ActiveColor

            self.icon = LoadIcon(icon, IconColor, IconThickness)
            self.IconSize = self.icon.get_size()

            self.hovering = False
            self.lasthovering = False
            self.activated = False

            self.hitbox = Surface((rect[2], rect[3]), SRCALPHA)
            draw.rrect(self.hitbox, [0, 0, self.rect[2], self.rect[3]], Colors.Real.White, self.radius) # border


            self.plate = Surface((rect[2], rect[3]), SRCALPHA)
            draw.rrect(self.plate, [0, 0, self.rect[2], self.rect[3]], self.border, self.radius) # border
            draw.rrect(self.plate, 
                    [self.width, self.width, self.rect[2]-self.width*2, self.rect[3]-self.width*2],
                    self.color, self.radius)
            if (icon): self.plate.blit(self.icon, ((self.rect[2]-self.IconSize[0])//2, (self.rect[3]-self.IconSize[1])//2))

            self.activeplate = Surface((rect[2], rect[3]), SRCALPHA)
            draw.rrect(self.activeplate, [0, 0, self.rect[2], self.rect[3]], self.border, self.radius) # border
            draw.rrect(self.activeplate, 
                    [self.width, self.width, self.rect[2]-self.width*2, self.rect[3]-self.width*2],
                    self.ActiveColor, self.radius)
            if (icon): self.activeplate.blit(self.icon, ((self.rect[2]-self.IconSize[0])//2, (self.rect[3]-self.IconSize[1])//2))
            pass

        def draw(self, **settings) -> None:
            plate = self.plate
            if (self.activated): plate = self.activeplate
            mouse = settings.get("mouse", (0, 0))
            MouseState = settings.get("MouseState", [0]*6)

            self.surface.blit(plate, (self.rect[0], self.rect[1]))

            # hit
            pos = mouse[0] - self.rect[0], mouse[1] - self.rect[1]
            if (pos[0]>=0 and pos[1]>=0 and pos[0]<self.rect[2] and pos[1]<self.rect[3]):
                color = self.hitbox.get_at(pos)
                if (color != Colors.Real.Black):
                    self.hovering = True
                    pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_HAND)

                    if (MouseState[0]):
                        self.activated = True

                else:
                    self.hovering = False
            else:
                self.hovering = False

            if (MouseState[1]):
                self.activated = False

            if (not self.hovering and self.lasthovering): pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_ARROW)
            self.lasthovering = self.hovering

            if (self.hovering and MouseState[1]):
                if (type(self.function) == str): exec(self.function)
                elif (self.function): self.function()

            return
        
