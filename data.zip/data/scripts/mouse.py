from win32api import GetKeyState

lastleft1 = 0
lastleft2 = 0
lastright2 = 0
lastright1 = 0
lastmiddle1 = 0
lastmiddle2 = 0

class mouse:
    def middlebtdown():
        global lastmiddle1
        middle = GetKeyState(0x04)
        if int(lastmiddle1) >=0 and middle <0:
            lastmiddle1 = middle
            return True
        else:
            lastmiddle1 = middle
            return False
    def middlebtup():
        global lastmiddle2
        middle = GetKeyState(0x02)
        if int(lastmiddle2) < 0 and middle >=0:
            lastmiddle2 = middle
            return True
        else:
            lastmiddle2=middle
            return False
    def rightbtdown():
        global lastright1
        right = GetKeyState(0x02)
        if int(lastright1) >= 0 and right <0:
            lastright1 = right
            return True
        else:
            lastright1=right
            return False
    def rightbtup():
        global lastright2
        right = GetKeyState(0x02)
        if int(lastright2) < 0 and right >=0:
            lastright2 = right
            return True
        else:
            lastright2=right
            return False
    def leftbtdown():
        global lastleft1
        left = GetKeyState(0x01)
        if int(lastleft1) >=0 and left <0:
            lastleft1 = left
            return True
        else:
            lastleft1 = left
            return False
    def leftbtup():
        global lastleft2
        left = GetKeyState(0x01)
        if int(lastleft2) < 0 and left >= 0:
            lastleft2 = left
            return True
        
        else:
            lastleft2 = left
            return False
        
    def state() -> list[bool, bool, bool, bool, bool, bool]:
        return [mouse.leftbtdown(), mouse.leftbtup(), mouse.middlebtdown(), mouse.middlebtup(), mouse.rightbtdown(), mouse.middlebtup()]