import os, pygame
from data.scripts.image import LoadImage
from win32gui import ShowWindow, SetWindowLong, GetWindowLong, SetWindowPos, GetWindowPlacement, error
from win32con import SW_HIDE, SW_SHOW, GWL_EXSTYLE, WS_EX_TOOLWINDOW, HWND_TOPMOST, SWP_NOSIZE, SW_MINIMIZE, SW_MAXIMIZE
from win32api import GetSystemMetrics

class HWND: pass

def minimize(hwnd:HWND) -> None:
    ShowWindow(hwnd, SW_MINIMIZE)

def maximize(hwnd:HWND) -> None:
    ShowWindow(hwnd, SW_MAXIMIZE)

def HideFromTaskBar(hwnd:HWND) -> None:
    try:
        ShowWindow(hwnd, SW_HIDE)
        SetWindowLong(hwnd, GWL_EXSTYLE,GetWindowLong(hwnd, GWL_EXSTYLE)| WS_EX_TOOLWINDOW)
        ShowWindow(hwnd, SW_SHOW)
    except error: print("Error while hiding the window")
    
    return

def GetScreenSize() -> tuple[int, int]:

    return GetSystemMetrics(0), GetSystemMetrics(1)

def AlwaysOnTop(hwnd) -> None:
    posX, posY, width, height = GetWindowPlacement(hwnd)[4]
    SetWindowPos(hwnd, HWND_TOPMOST, posX,posY, 0,0, SWP_NOSIZE)

def init(
        size:tuple[int, int]=(512, 512),
        pos:tuple[int, int]=None,
        caption:str="Window",
        flags=None,
        icon:str=None,
        HideFromTaskBar_:bool=False,
         ) -> (pygame.Surface, HWND):
    
    pygame.init()
    if (pos): os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % pos

    window = pygame.display.set_mode((1, 1), pygame.NOFRAME)
    hwnd=pygame.display.get_wm_info()["window"]

    if (icon): pygame.display.set_icon(LoadImage(icon))
    if (HideFromTaskBar_): HideFromTaskBar(hwnd)

    window = pygame.display.set_mode(size, flags)
    pygame.display.set_caption(caption)

    return window, hwnd