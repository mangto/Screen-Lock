import pygame
from os.path import isfile
from os import listdir
from copy import copy
from PIL import ImageGrab, ImageFilter


failed = pygame.Surface((64, 64))
failed.fill((255, 0, 0))


def LoadImage(file:str) -> pygame.Surface:    
    path:str
    if (file in listdir(".\\data\\img")):
        path = ".\\data\\img\\"+file

    else:
        path = file

    image = pygame.image.load(path)
    image = image.convert_alpha()

    return image

def pilImageToSurface(pilImage):
    return pygame.image.fromstring(
        pilImage.tobytes(), pilImage.size, pilImage.mode).convert()

def screenshot(blur:int=0) -> pygame.Surface:
    image = ImageGrab.grab()
    if (blur): image = image.filter(ImageFilter.GaussianBlur(blur))
    surface = pilImageToSurface(image)

    return surface

def colorize(image, newColor):

    image = image.copy()

    image.fill((0, 0, 0, 255), None, pygame.BLEND_RGBA_MULT)
    image.fill(newColor[0:3] + (0,), None, pygame.BLEND_RGBA_ADD)

    return image