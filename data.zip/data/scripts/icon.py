import pygame
from data.scripts.colors import *
from data.scripts.image import *
from io import BytesIO

icons = ['alarm', 'alert-circle', 'apps', 'archive', 'arrow-down', 'arrow-left', 'arrow-right',
         'arrow-up', 'attach', 'award-alt', 'award', 'backspace', 'bag-alt', 'bag-r', 'bag', 'bank', 
         'battery-charge', 'battery', 'bell', 'bolt-alt', 'bolt', 'book', 'bookmark', 'calendar-check',
         'calendar', 'camera', 'card', 'cart', 'cash', 'chart-down', 'chart-histogramm', 'chart-line', 
         'chart-pie', 'chart-up', 'checkmark', 'chevron-down', 'chevron-left', 'chevron-right', 
         'chevron-up', 'clipboard-alt', 'clipboard', 'clock', 'close-circle', 'close', 'cloud-download',
         'cloud', 'code', 'coins', 'comment', 'comments', 'copy', 'crosshair', 'cup', 'dashboard', 'desktop',
         'dislike', 'dollar', 'dots-alt', 'dots', 'download', 'education', 'email', 'euro', 'exchange', 
         'eye-closed', 'eye', 'file-alt', 'file', 'filter', 'flag-alt', 'flag', 'focus', 'folder-add', 
         'folder-check', 'folder-delete', 'folder', 'forward', 'gamepad', 'gear-alt', 'gear', 'gift', 
         'headphones', 'heart', 'home', 'image', 'key', 'lightbulb', 'like', 'link', 'location', 
         'lock-opened', 'lock', 'magnify-minus', 'magnify-plus', 'menu', 'microphone', 'minus-circle', 
         'minus', 'mobile', 'moon', 'mouse', 'music', 'no-entry', 'note', 'pause', 'pencil', 'phone', 
         'pin', 'plane', 'planet', 'play', 'pluc-circle', 'plus', 'pound', 'power', 'presentation', 
         'print', 'question-circle', 'refresh', 'reply', 'rocket', 'ruble', 'sandwatch-alt', 'sandwatch', 
         'save', 'search', 'send', 'shield-check', 'shield', 'sitemap', 'sliders', 'smile-confuse', 
         'smile-happy', 'smile-sad', 'sort', 'stack', 'star', 'sun', 'tag', 'trash-alt', 'trash', 
         'umbrella', 'upload', 'user', 'video', 'volume', 'wallet', 'watch', 'wifi', 'yen']

thickmap = {
    "m":"m",
    "medium":"m",
    "r":"r",
    "regular":"r",
    "t":"t",
    "thin":"t"
}

def LoadSVG(file:str, scale:float=1.0):
    svg_string = open(file, "rt").read()
    start = svg_string.find('<svg')    
    if start > 0:
        svg_string = svg_string[:start+4] + f' transform="scale({scale}, {scale})"' + svg_string[start+4:]
    return pygame.image.load(BytesIO(svg_string.encode()))

def LoadIcon(name:str, color:tuple[int, int, int]=Colors.Real.Gray, thickness:str="r") -> pygame.Surface:
    if (name not in icons): return pygame.Surface((24, 24))
    thickness = thickmap.get(thickness.lower(), "r")

    path = ".\\data\\icon\\"
    match thickness:
        case "m": path = path + "Medium\\" + name + "-m.svg"
        case "r": path = path + "Regular\\" + name + "-r.svg"
        case "t": path = path + "Thin\\" + name + "-t.svg"

    icon = LoadSVG(path)
    icon = colorize(icon, color)


    return icon