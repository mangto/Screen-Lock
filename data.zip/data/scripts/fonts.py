from os import listdir
from pygame.font import Font

fontmap = {
    c[:c.rfind(".")].lower():c for c in listdir("C:\\Windows\\Fonts")
}


def font(name:str, size:int) -> Font:

    name = name.lower()

    if name not in fontmap:
        print("Cannot Find Font")
        return Font(f"C:\\Windows\\Fonts\\Arial.ttf", size)
    return Font(f"C:\\Windows\\Fonts\\{fontmap[name]}", size)