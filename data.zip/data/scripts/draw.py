import pygame
from pygame import gfxdraw

class draw:
    def text(text, font, canvas, x, y, cenleft="center", color=(0,0,0)):
        text_obj = font.render(text, True, color)
        text_rect=text_obj.get_rect()
        if(cenleft == "center"):
            text_rect.centerx = x
            text_rect.centery = y
        elif(cenleft == "left"):
            text_rect.left=x
            text_rect.top=y
        elif(cenleft == "right"):
            text_rect.right=x
            text_rect.top=y
        elif(cenleft == "btright"):
            text_rect.right=x
            text_rect.bottom=y
        elif(cenleft == "cenleft"):
            text_rect.left=x
            text_rect.centery=y
        elif(cenleft == "cenright"):
            text_rect.right=x
            text_rect.centery=y
        elif(cenleft == "btcen"):
            text_rect.centerx=x
            text_rect.bottom=y
        elif(cenleft == "topcen"):
            text_rect.centerx=x
            text_rect.top=y
        canvas.blit(text_obj, text_rect)

        
    def gettsize(text,font):
        return font.render(text,True,(0,0,0)).get_rect().size
    
    def aacircle(surface, x, y, radius, color):
        gfxdraw.aacircle(surface, x, y, radius, color)
        gfxdraw.filled_circle(surface, x, y, radius, color)

    def rrect(surface,rect,color,radius=0.4):
        rect         = pygame.Rect(rect)
        color        = pygame.Color(*color)
        alpha        = color.a
        color.a      = 0
        pos          = rect.topleft
        rect.topleft = 0,0
        rectangle    = pygame.Surface(rect.size,pygame.SRCALPHA)
        circle       = pygame.Surface([min(rect.size)*3]*2,pygame.SRCALPHA)
        pygame.draw.ellipse(circle,(0,0,0),circle.get_rect(),0)
        circle       = pygame.transform.smoothscale(circle,[int(min(rect.size)*radius)]*2)
        radius              = rectangle.blit(circle,(0,0))
        radius.bottomright  = rect.bottomright
        rectangle.blit(circle,radius)
        radius.topright     = rect.topright
        rectangle.blit(circle,radius)
        radius.bottomleft   = rect.bottomleft
        rectangle.blit(circle,radius)

        rectangle.fill((0,0,0),rect.inflate(-radius.w,0))
        rectangle.fill((0,0,0),rect.inflate(0,-radius.h))

        rectangle.fill(color,special_flags=pygame.BLEND_RGBA_MAX)
        rectangle.fill((255,255,255,alpha),special_flags=pygame.BLEND_RGBA_MIN)
        return surface.blit(rectangle,pos)
    
    def trirect(surface,x,y,sx,sy,tri,color,edge=(1,1,1,1)):
        if sx < tri*2:
            sx = tri*2
        if sy < tri*2:
            sy = tri*2

        pygame.draw.rect(surface,color,[x+tri,y,sx-tri*2,sy])
        pygame.draw.rect(surface,color,[x,y+tri,sx,sy-tri*2])
        if edge[0] == 1:
            pygame.draw.polygon(surface,color,[[x,y+tri],[x+tri,y],[x+tri,y+tri]])
        else:
            pygame.draw.rect(surface,color,[x,y,tri,tri])
        if edge[1] == 1:
            pygame.draw.polygon(surface,color,[[x+sx-tri,y+1],[x+sx-1,y+tri],[x+sx-tri,y+tri]])
        else:
            pygame.draw.rect(surface,color,[x+sx-tri,y,tri,tri])
        if edge[2] == 1:
            pygame.draw.polygon(surface,color,[[x,y+sy-tri],[x+tri,y+sy-1],[x+tri,y+sy-tri]])
        else:
            pygame.draw.rect(surface,color,[x,y+sy-tri,tri,tri])
        if edge[3] == 1:
            pygame.draw.polygon(surface,color,[[x+sx-1,y+sy-tri],[x+sx-tri,y+sy-1],[x+sx-tri,y+sy-tri]])
        else:
            pygame.draw.rect(surface,color,[x+sx-tri,y+sy-tri,tri,tri])