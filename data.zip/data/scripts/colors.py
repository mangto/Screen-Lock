def rgb(r, g, b): return (r, g, b)

class Colors:
    class Palette:
        Black = rgb(39, 40, 41)
        Dark = rgb(97, 103, 122)
        Bright = rgb(216, 217, 218)
        White = rgb(255, 246, 224)

    class Real:
        Black = rgb(0, 0, 0)
        White = rgb(255, 255, 255)
        Red = rgb(255, 0, 0)
        Green = rgb(0, 255, 0)
        Blue = rgb(0, 0, 255)
        LightGray = rgb(208, 209, 208)
        Gray = rgb(65, 72, 85)
        DarkGray = rgb(40, 44, 52)
        Purple = rgb(72, 12, 168)